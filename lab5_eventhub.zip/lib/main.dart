import 'package:flutter/material.dart';

void main() {
  runApp(const EventHubApp());
}

class EventHubApp extends StatelessWidget {
  const EventHubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EventHub',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const EventListScreen(),
    );
  }
}

class EventCategory {
  final String name;
  final IconData icon;
  final Color color;
  const EventCategory(
      {required this.name, required this.icon, required this.color});
}

class Event {
  String title;
  String description;
  String location;
  EventCategory category;
  DateTime date;
  TimeOfDay time;
  List<String> participants;
  String emoji;

  Event({
    required this.title,
    required this.description,
    required this.location,
    required this.category,
    required this.date,
    required this.time,
    required this.participants,
    required this.emoji,
  });
}

const categories = [
  EventCategory(name: 'Учёба', icon: Icons.school, color: Colors.blue),
  EventCategory(name: 'Спорт', icon: Icons.sports_soccer, color: Colors.green),
  EventCategory(
      name: 'Развлечения', icon: Icons.celebration, color: Colors.orange),
  EventCategory(name: 'Работа', icon: Icons.work, color: Colors.red),
  EventCategory(name: 'Личное', icon: Icons.favorite, color: Colors.pink),
];

List<Event> events = [
  Event(
      title: 'Лекция по Flutter',
      description: 'Изучаем виджеты и архитектуру.',
      location: 'Ауд. 305',
      category: categories[0],
      date: DateTime.now(),
      time: const TimeOfDay(hour: 9, minute: 0),
      participants: ['Иванов А.', 'Петрова Б.'],
      emoji: '📚'),
  Event(
      title: 'Футбол',
      description: 'Товарищеский матч.',
      location: 'Стадион',
      category: categories[1],
      date: DateTime.now().add(const Duration(days: 1)),
      time: const TimeOfDay(hour: 18, minute: 30),
      participants: ['Команда А'],
      emoji: '⚽'),
];

class EventListScreen extends StatefulWidget {
  const EventListScreen({super.key});
  @override
  State<EventListScreen> createState() => _EventListScreenState();
}

class _EventListScreenState extends State<EventListScreen> {
  String _selectedCategory = 'Все';
  String _searchQuery = '';
  String _sortBy = 'Дата';

  List<Event> get _filteredEvents {
    var list = events
        .where((e) =>
            (_selectedCategory == 'Все' ||
                e.category.name == _selectedCategory) &&
            e.title.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();

    if (_sortBy == 'Название') list.sort((a, b) => a.title.compareTo(b.title));
    return list;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('EventHub'),
        actions: [
          IconButton(
              icon: const Icon(Icons.pie_chart),
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => StatisticsScreen(events: events)))),
          PopupMenuButton<String>(
            icon: const Icon(Icons.sort),
            onSelected: (val) => setState(() => _sortBy = val),
            itemBuilder: (_) => ['Дата', 'Название']
                .map((e) => PopupMenuItem(value: e, child: Text(e)))
                .toList(),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                  decoration: const InputDecoration(
                      hintText: 'Поиск...',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder()),
                  onChanged: (val) => setState(() => _searchQuery = val))),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              ChoiceChip(
                  label: const Text('Все'),
                  selected: _selectedCategory == 'Все',
                  onSelected: (_) => setState(() => _selectedCategory = 'Все')),
              ...categories.map((cat) => Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: ChoiceChip(
                      label: Text(cat.name),
                      selected: _selectedCategory == cat.name,
                      onSelected: (_) =>
                          setState(() => _selectedCategory = cat.name)))),
            ]),
          ),
          Expanded(
              child: GridView.count(
                  crossAxisCount: 2,
                  padding: const EdgeInsets.all(10),
                  children:
                      _filteredEvents.map((e) => _buildEventCard(e)).toList())),
        ],
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () => _showAddEventSheet(context),
          child: const Icon(Icons.add)),
    );
  }

  Widget _buildEventCard(Event event) {
    return Dismissible(
      key: ValueKey(event),
      direction: DismissDirection.endToStart,
      background: Container(
          color: Colors.red,
          alignment: Alignment.centerRight,
          child: const Icon(Icons.delete, color: Colors.white)),
      onDismissed: (_) {
        setState(() => events.remove(event));
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('${event.title} удалено'),
            action: SnackBarAction(
                label: 'Отмена',
                onPressed: () => setState(() => events.add(event)))));
      },
      child: GestureDetector(
        onTap: () async {
          await Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => EventDetailScreen(
                      event: event,
                      onEdit: () {
                        Navigator.pop(context);
                        _showAddEventSheet(context, eventToEdit: event);
                      })));
          setState(() {});
        },
        child: Card(
          child: Column(children: [
            Container(
                color: event.category.color.withOpacity(0.3),
                height: 70,
                width: double.infinity,
                child: Center(
                    child: Text(event.emoji,
                        style: const TextStyle(fontSize: 30)))),
            Padding(
                padding: const EdgeInsets.all(8),
                child: Text(event.title,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                    maxLines: 2)),
          ]),
        ),
      ),
    );
  }

  void _showAddEventSheet(BuildContext context, {Event? eventToEdit}) {
    final titleCtrl = TextEditingController(text: eventToEdit?.title ?? '');
    final descCtrl =
        TextEditingController(text: eventToEdit?.description ?? '');
    final locCtrl = TextEditingController(text: eventToEdit?.location ?? '');
    final partCtrl = TextEditingController();

    EventCategory selectedCat = eventToEdit?.category ?? categories[0];
    List<String> currentParticipants =
        List.from(eventToEdit?.participants ?? []);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.only(
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              left: 20,
              right: 20,
              top: 20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(eventToEdit == null ? 'Новое событие' : 'Редактирование',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                TextField(
                    controller: titleCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Название', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                TextField(
                    controller: descCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Описание', border: OutlineInputBorder()),
                    maxLines: 2),
                const SizedBox(height: 8),
                TextField(
                    controller: locCtrl,
                    decoration: const InputDecoration(
                        labelText: 'Место', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                DropdownButtonFormField<EventCategory>(
                  value: selectedCat,
                  decoration: const InputDecoration(
                      labelText: 'Категория', border: OutlineInputBorder()),
                  items: categories
                      .map((cat) =>
                          DropdownMenuItem(value: cat, child: Text(cat.name)))
                      .toList(),
                  onChanged: (val) => setSheetState(() => selectedCat = val!),
                ),
                const SizedBox(height: 15),
                const Text('Участники:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Row(children: [
                  Expanded(
                      child: TextField(
                          controller: partCtrl,
                          decoration: const InputDecoration(
                              labelText: 'Имя участника'))),
                  IconButton(
                      icon: const Icon(Icons.add),
                      onPressed: () {
                        if (partCtrl.text.isNotEmpty)
                          setSheetState(() {
                            currentParticipants.add(partCtrl.text);
                            partCtrl.clear();
                          });
                      })
                ]),
                Wrap(
                  spacing: 8,
                  children: currentParticipants
                      .map<Widget>((p) => InputChip(
                            label: Text(p),
                            onDeleted: () {
                              setSheetState(() {
                                currentParticipants.remove(p);
                              });
                            },
                          ))
                      .toList(),
                ),
                const SizedBox(height: 15),
                FilledButton(
                  onPressed: () {
                    if (titleCtrl.text.isEmpty) return;
                    setState(() {
                      if (eventToEdit == null) {
                        events.add(Event(
                          title: titleCtrl.text,
                          description: descCtrl.text,
                          location: locCtrl.text,
                          category: selectedCat,
                          date: DateTime.now(),
                          time: TimeOfDay.now(),
                          participants: currentParticipants,
                          emoji: '🎉',
                        ));
                      } else {
                        eventToEdit.title = titleCtrl.text;
                        eventToEdit.description = descCtrl.text;
                        eventToEdit.location = locCtrl.text;
                        eventToEdit.category = selectedCat;
                        eventToEdit.participants = currentParticipants;
                      }
                    });
                    Navigator.pop(ctx);
                  },
                  child: Text(eventToEdit == null ? 'Создать' : 'Сохранить'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class EventDetailScreen extends StatelessWidget {
  final Event event;
  final VoidCallback onEdit;
  const EventDetailScreen(
      {super.key, required this.event, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(event.title), actions: [
        IconButton(icon: const Icon(Icons.edit), onPressed: onEdit)
      ]),
      body: SingleChildScrollView(
        child: Column(children: [
          ExpansionTile(
              title: const Text('Описание'),
              initiallyExpanded: true,
              children: [
                Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(event.description))
              ]),
          ExpansionTile(
              title: Text('Участники (${event.participants.length})'),
              children: event.participants
                  .map((p) => ListTile(title: Text(p)))
                  .toList()),
        ]),
      ),
    );
  }
}

class StatisticsScreen extends StatelessWidget {
  final List<Event> events;
  const StatisticsScreen({super.key, required this.events});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Статистика')),
      body: ListView(
        children: categories.map((cat) {
          int count = events.where((e) => e.category.name == cat.name).length;
          return Card(
            child: ListTile(
              leading: CircularProgressIndicator(
                  value: events.isEmpty ? 0 : count / events.length,
                  color: cat.color),
              title: Text(cat.name),
              trailing: Text('$count событий'),
            ),
          );
        }).toList(),
      ),
    );
  }
}
