import 'package:flutter/material.dart';

void main() {
  runApp(const CafeApp());
}

class CafeApp extends StatelessWidget {
  const CafeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Кафе "У Flutter"',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.brown),
        useMaterial3: true,
      ),
      home: const CategoriesScreen(),
    );
  }
}

class Dish {
  final String name;
  final String description;
  final double price;
  final String emoji;
  final List<String> ingredients;

  const Dish({
    required this.name,
    required this.description,
    required this.price,
    required this.emoji,
    required this.ingredients,
  });
}

class Category {
  final String name;
  final String emoji;
  final Color color;
  final List<Dish> dishes;

  const Category({
    required this.name,
    required this.emoji,
    required this.color,
    required this.dishes,
  });
}

List<Map<String, dynamic>> cart = [];

final List<Category> menuData = [
  Category(
    name: 'Завтраки',
    emoji: '🍳',
    color: Colors.orange,
    dishes: [
      const Dish(
        name: 'Омлет с сыром',
        description: 'Пышный омлет из трёх яиц с тёртым сыром и зеленью.',
        price: 250,
        emoji: '🍳',
        ingredients: ['Яйца', 'Сыр', 'Молоко', 'Зелень'],
      ),
      const Dish(
        name: 'Овсянка с ягодами',
        description: 'Овсяная каша на молоке со свежими ягодами и мёдом.',
        price: 200,
        emoji: '🥣',
        ingredients: ['Овсянка', 'Молоко', 'Ягоды', 'Мёд'],
      ),
      const Dish(
        name: 'Блинчики',
        description: 'Тонкие блинчики с вареньем или сметаной на выбор.',
        price: 220,
        emoji: '🥞',
        ingredients: ['Мука', 'Яйца', 'Молоко', 'Варенье'],
      ),
    ],
  ),
  Category(
    name: 'Супы',
    emoji: '🍲',
    color: Colors.red,
    dishes: [
      const Dish(
        name: 'Борщ',
        description: 'Наваристый борщ со сметаной и чесночными пампушками.',
        price: 320,
        emoji: '🥣',
        ingredients: ['Свёкла', 'Капуста', 'Картофель', 'Мясо', 'Сметана'],
      ),
      const Dish(
        name: 'Куриный бульон',
        description: 'Лёгкий куриный бульон с лапшой и зеленью.',
        price: 280,
        emoji: '🍜',
        ingredients: ['Курица', 'Лапша', 'Морковь', 'Зелень'],
      ),
    ],
  ),
  Category(
    name: 'Напитки',
    emoji: '☕',
    color: Colors.brown,
    dishes: [
      const Dish(
        name: 'Капучино',
        description: 'Классический капучино с молочной пенкой.',
        price: 180,
        emoji: '☕',
        ingredients: ['Эспрессо', 'Молоко'],
      ),
      const Dish(
        name: 'Чай с лимоном',
        description: 'Чёрный чай с долькой лимона и мёдом.',
        price: 120,
        emoji: '🫖',
        ingredients: ['Чай', 'Лимон', 'Мёд'],
      ),
      const Dish(
        name: 'Морс',
        description: 'Домашний ягодный морс из клюквы и брусники.',
        price: 150,
        emoji: '🥤',
        ingredients: ['Клюква', 'Брусника', 'Сахар'],
      ),
    ],
  ),
  Category(
    name: 'Десерты',
    emoji: '🍰',
    color: Colors.pink,
    dishes: [
      const Dish(
        name: 'Чизкейк',
        description: 'Нежный чизкейк с ягодным соусом.',
        price: 350,
        emoji: '🍰',
        ingredients: ['Сливочный сыр', 'Печенье', 'Ягодный соус'],
      ),
      const Dish(
        name: 'Тирамису',
        description: 'Итальянский десерт с маскарпоне и кофе.',
        price: 380,
        emoji: '🍮',
        ingredients: ['Маскарпоне', 'Савоярди', 'Кофе', 'Какао'],
      ),
    ],
  ),
  Category(
    name: 'Основные блюда',
    emoji: '🥩',
    color: Colors.deepOrange,
    dishes: [
      const Dish(
        name: 'Стейк Рибай',
        description: 'Сочный говяжий стейк прожарки Medium с соусом.',
        price: 950,
        emoji: '🥩',
        ingredients: ['Говядина', 'Специи', 'Масло', 'Соус'],
      ),
      const Dish(
        name: 'Паста Карбонара',
        description: 'Классическая итальянская паста с беконом и пармезаном.',
        price: 450,
        emoji: '🍝',
        ingredients: ['Спагетти', 'Бекон', 'Сливки', 'Пармезан'],
      ),
      const Dish(
        name: 'Бургер от Шефа',
        description:
            'Большой бургер с говяжьей котлетой, сыром и картофелем фри.',
        price: 550,
        emoji: '🍔',
        ingredients: ['Булочка', 'Котлета', 'Сыр', 'Салат', 'Картофель'],
      ),
    ],
  ),
];

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  String _searchText = '';

  @override
  Widget build(BuildContext context) {
    final searchResults = menuData
        .expand(
            (cat) => cat.dishes.map((dish) => {'dish': dish, 'category': cat}))
        .where((item) => (item['dish'] as Dish)
            .name
            .toLowerCase()
            .contains(_searchText.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Кафе "У Flutter"'),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const CartScreen()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Поиск блюд...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (value) {
                setState(() {
                  _searchText = value;
                });
              },
            ),
          ),
          Expanded(
            child: _searchText.isEmpty
                ? ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: menuData.length,
                    itemBuilder: (context, index) {
                      final category = menuData[index];
                      return _buildCategoryCard(context, category);
                    },
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: searchResults.length,
                    itemBuilder: (context, index) {
                      final item = searchResults[index];
                      final dish = item['dish'] as Dish;
                      final category = item['category'] as Category;

                      return Card(
                        margin: const EdgeInsets.only(bottom: 12),
                        child: ListTile(
                          leading: Text(dish.emoji,
                              style: const TextStyle(fontSize: 24)),
                          title: Text(dish.name),
                          subtitle: Text('${dish.price.toInt()} ₽'),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DishDetailScreen(
                                  dish: dish,
                                  categoryColor: category.color,
                                ),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(BuildContext context, Category category) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DishesScreen(category: category),
            ),
          );
        },
        child: Container(
          height: 100,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                category.color.withOpacity(0.7),
                category.color.withOpacity(0.3),
              ],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Text(
                  category.emoji,
                  style: const TextStyle(fontSize: 44),
                ),
                const SizedBox(width: 20),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        category.name,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${category.dishes.length} позиций',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.white.withOpacity(0.8),
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.arrow_forward_ios,
                  color: Colors.white70,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class DishesScreen extends StatelessWidget {
  final Category category;

  const DishesScreen({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${category.emoji} ${category.name}'),
        backgroundColor: category.color.withOpacity(0.3),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: category.dishes.length,
        itemBuilder: (context, index) {
          final dish = category.dishes[index];
          return _buildDishCard(context, dish);
        },
      ),
    );
  }

  Widget _buildDishCard(BuildContext context, Dish dish) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DishDetailScreen(
                dish: dish,
                categoryColor: category.color,
              ),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: category.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    dish.emoji,
                    style: const TextStyle(fontSize: 28),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      dish.name,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      dish.description,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: category.color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${dish.price.toInt()} ₽',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: category.color,
                    fontSize: 15,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DishDetailScreen extends StatefulWidget {
  final Dish dish;
  final Color categoryColor;

  const DishDetailScreen({
    super.key,
    required this.dish,
    required this.categoryColor,
  });

  @override
  State<DishDetailScreen> createState() => _DishDetailScreenState();
}

class _DishDetailScreenState extends State<DishDetailScreen> {
  int _quantity = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.dish.name),
        backgroundColor: widget.categoryColor.withOpacity(0.3),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 200,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    widget.categoryColor.withOpacity(0.4),
                    widget.categoryColor.withOpacity(0.1),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Center(
                child: Text(
                  widget.dish.emoji,
                  style: const TextStyle(fontSize: 100),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.dish.name,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${widget.dish.price.toInt()} ₽',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: widget.categoryColor,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    widget.dish.description,
                    style: const TextStyle(
                      fontSize: 16,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Состав:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: widget.dish.ingredients
                        .map((item) => Chip(
                              avatar: Icon(
                                Icons.check_circle,
                                size: 18,
                                color: widget.categoryColor,
                              ),
                              label: Text(item),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 32),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: () {
                          if (_quantity > 1) {
                            setState(() {
                              _quantity--;
                            });
                          }
                        },
                        icon: const Icon(Icons.remove_circle_outline),
                        iconSize: 36,
                        color: widget.categoryColor,
                      ),
                      const SizedBox(width: 16),
                      Text(
                        '$_quantity',
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(width: 16),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            _quantity++;
                          });
                        },
                        icon: const Icon(Icons.add_circle_outline),
                        iconSize: 36,
                        color: widget.categoryColor,
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton(
                      onPressed: () {
                        cart.add({
                          'name': widget.dish.name,
                          'price': widget.dish.price,
                          'quantity': _quantity,
                          'emoji': widget.dish.emoji,
                        });

                        final total = widget.dish.price * _quantity;

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(
                              '${widget.dish.name} x$_quantity = ${total.toInt()} ₽ добавлено в заказ!',
                            ),
                            backgroundColor: widget.categoryColor,
                          ),
                        );
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: widget.categoryColor,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text(
                        'В заказ — ${(widget.dish.price * _quantity).toInt()} ₽',
                        style: const TextStyle(fontSize: 18),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    double totalSum = 0;
    for (var item in cart) {
      totalSum += item['price'] * item['quantity'];
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Корзина'),
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      ),
      body: cart.isEmpty
          ? const Center(
              child: Text(
                'Корзина пуста 😔\nДобавьте вкусняшки из меню!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: cart.length,
                    itemBuilder: (context, index) {
                      final item = cart[index];
                      final sum = (item['price'] * item['quantity']).toInt();
                      return ListTile(
                        leading: Text(item['emoji'],
                            style: const TextStyle(fontSize: 24)),
                        title: Text(item['name']),
                        subtitle: Text(
                            '${item['price'].toInt()} ₽  x  ${item['quantity']} шт.'),
                        trailing: Text(
                          '$sum ₽',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      );
                    },
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(24)),
                  ),
                  child: SafeArea(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Итого:',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${totalSum.toInt()} ₽',
                          style: const TextStyle(
                              fontSize: 26, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
    );
  }
}
